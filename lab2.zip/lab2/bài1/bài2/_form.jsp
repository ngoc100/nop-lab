<%@ page pageEncoding="utf-8"%>
<h3>User Edition</h3>
<form action="/user.php" method="post">
    Username: <input name="username" value="${form.username}"><br><br>
    Password: <input name="password" type="password" value="${form.password}"><br><br>
    <input name="remember" type="checkbox" ${form.remember ? 'checked' : ''}> Remember me?
    <br><br>
    <button type="submit">Create</button>
</form>