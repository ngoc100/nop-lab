<%@ page pageEncoding="utf-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>
</head>
<body>
    <h2>User Management</h2>
    <p style="color: green; font-weight: bold;">${message}</p>
    
    <jsp:include page="_form.jsp"/>
    <hr>
    <jsp:include page="_table.jsp"/>
</body>
</html>