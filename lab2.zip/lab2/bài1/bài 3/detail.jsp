<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
    <title>Chi tiết sản phẩm</title>
</head>
<body>

    <h2>Chi tiết sản phẩm</h2>
    <hr>
    <h3>Tên sản phẩm: ${item.name}</h3>
    <p><img src="images/${item.image}" width="200" alt="${item.name}"></p>
    
    <p>Giá gốc: $${item.price}</p>
    
    <c:set var="newPrice" value="${item.price * (1 - item.discount)}" />
    <p>Giá mới: $${newPrice}</p>
    
    <p>Mức giá: 
        <c:choose>
            <c:when test="${newPrice < 10}">
                <span style="color: blue; font-weight: bold;">Giá thấp</span>
            </c:when>
            <c:when test="${newPrice > 100}">
                <span style="color: red; font-weight: bold;">Giá cao</span>
            </c:when>
            <c:otherwise>
                <span>Bình thường</span>
            </c:otherwise>
        </c:choose>
    </p>

    <p>Ngày nhập: <fmt:formatDate value="${item.date}" pattern="dd - MM - yyyy" /></p>
    
    <p><a href="/layout.jsp">Quay lại danh sách sản phẩm</a></p>

</body>
</html>     