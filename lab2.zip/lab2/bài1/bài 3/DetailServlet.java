package com.example;

import com.fpoly.model.Item;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/detail.php")
public class DetailServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        // Đọc tham số tên từ trang danh sách gửi sang (nếu có)
        String pName = req.getParameter("name");
        if(pName == null || pName.isEmpty()) {
            pName = "Nokia 2026";
        }

        Item item = new Item(pName, "nokia.png", 500, 0.1);
        req.setAttribute("item", item);
        
        req.getRequestDispatcher("/views/item/detail.jsp").forward(req, resp);
    }
}