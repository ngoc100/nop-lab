<%@ page pageEncoding="utf-8"%>
<h3>Login Form</h3>
<form>
    Username?<br>
    <input type="text" name="username" style="width:100%;"><br>
    Password?<br>
    <input type="password" name="password" style="width:100%;"><br>
    <input type="checkbox" name="remember"> Remember me?<br><br>
    <button type="submit">Login</button>
</form>