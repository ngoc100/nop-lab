<%@ page pageEncoding="utf-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Online Shopping Mall</title>
    <style>
        .container { width: 1000px; margin: 0 auto; display: flex; flex-wrap: wrap; }
        .header, .footer { width: 100%; background: #f1f1f1; padding: 15px; text-align: center; }
        .menu { width: 100%; background: #333; color: white; padding: 10px; }
        .menu a { color: white; margin-right: 15px; text-decoration: none; }
        .aside { width: 25%; padding: 15px; background: #fafafa; box-sizing: border-box; }
        .article { width: 75%; padding: 15px; box-sizing: border-box; }
        .row { display: flex; flex-wrap: wrap; }
        .product-box { width: 31%; margin: 1%; border: 1px solid #ddd; padding: 10px; box-sizing: border-box; text-align: center; }
        .product-box img { max-width: 100%; height: auto; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>Logo</h1>
    </div>

    <div class="menu">
        <%@include file="menu.jsp" %>
    </div>

    <div class="aside">
        <%@include file="login.jsp" %>
        <hr>
        <%@include file="category.jsp" %>
    </div>

    <div class="article">
        <h2>HIỂN THỊ DANH SÁCH SẢN PHẨM</h2>
        <div class="row">
            <jsp:include page="item.jsp">
                <jsp:param name="name" value="Nokia Pro 2026"/>
                <jsp:param name="image" value="nokia.png"/>
                <jsp:param name="price" value="100"/>
                <jsp:param name="discount" value="0.1"/>
            </jsp:include>
            
            <jsp:include page="item.jsp">
                <jsp:param name="name" value="iPhone 17 Pro Max"/>
                <jsp:param name="image" value="iphone.png"/>
                <jsp:param name="price" value="1200"/>
                <jsp:param name="discount" value="0.05"/>
            </jsp:include>

            <jsp:include page="item.jsp">
                <jsp:param name="name" value="Samsung Galaxy S26"/>
                <jsp:param name="image" value="samsung.png"/>
                <jsp:param name="price" value="950"/>
                <jsp:param name="discount" value="0.15"/>
            </jsp:include>
        </div>
    </div>

    <div class="footer">
        <p>FPT Polytechnic @2020 - 2026. All rights reserved.</p>
    </div>
</div>

</body>
</html>