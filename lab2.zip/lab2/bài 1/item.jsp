<%@ page pageEncoding="utf-8"%>
<div class="product-box">
    <a href="/detail.php?name=${param.name}">
        <img src="images/${param.image}" alt="${param.name}" />
    </a>
    <h4>${param.name}</h4>
    <p style="text-decoration: line-through; color: gray;">$${param.price}</p>
    <p style="color: red; font-weight: bold;">
        $${param.price * (1 - param.discount)}
    </p>
</div>