<%@ page pageEncoding="utf-8"%>
<h3>LOẠI SẢN PHẨM</h3>
<ul>
    <li><a href="#">LOẠI SẢN PHẨM 1</a></li>
    <li><a href="#">LOẠI SẢN PHẨM 2</a></li>
    <li><a href="#">LOẠI SẢN PHẨM 3</a></li>
</ul>