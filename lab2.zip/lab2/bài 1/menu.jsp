<%@ page pageEncoding="utf-8"%>
<a href="#">HOME</a>
<a href="#">ABOUT US</a>
<a href="#">CONTACT US</a>
<a href="#">FEEDBACK</a>