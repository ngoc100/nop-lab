package lab3.bai1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {

        Connection conn = DBConnection.getConnection();

        if (conn == null) {
            System.out.println("Không thể kết nối CSDL!");
            return;
        }

        try {

            Statement st = conn.createStatement();

            // =====================================
            // 1. Truy vấn toàn bộ nhân viên
            // =====================================

            System.out.println("===== DANH SÁCH NHÂN VIÊN =====");

            String sql1 = "SELECT * FROM employees";

            ResultSet rs1 = st.executeQuery(sql1);

            while (rs1.next()) {

                int id = rs1.getInt("id");
                String name = rs1.getString("name");
                double salary = rs1.getDouble("salary");
                int deptId = rs1.getInt("department_id");

                // Validation dữ liệu
                if (name == null || name.trim().isEmpty()) {
                    System.out.println("Tên nhân viên không hợp lệ!");
                    continue;
                }

                if (salary < 0) {
                    System.out.println("Lương nhân viên không hợp lệ!");
                    continue;
                }

                System.out.printf(
                        "%d | %s | %.2f | %d%n",
                        id, name, salary, deptId
                );
            }

            // =====================================
            // 2. Lọc phòng ban có >= 2 nhân viên
            // =====================================

            System.out.println("\n===== PHÒNG BAN CÓ TỪ 2 NHÂN VIÊN =====");

            String sql2 =
                    "SELECT d.id, d.name, COUNT(e.id) AS total " +
                    "FROM departments d " +
                    "JOIN employees e ON d.id = e.department_id " +
                    "GROUP BY d.id, d.name " +
                    "HAVING COUNT(e.id) >= 2";

            ResultSet rs2 = st.executeQuery(sql2);

            while (rs2.next()) {

                int id = rs2.getInt("id");
                String name = rs2.getString("name");
                int total = rs2.getInt("total");

                System.out.println(
                        id + " | " + name + " | " + total + " nhân viên"
                );
            }

            // =====================================
            // 3. Thống kê theo phòng ban
            // =====================================

            System.out.println("\n===== THỐNG KÊ NHÂN VIÊN THEO PHÒNG BAN =====");

            String sql3 =
                    "SELECT d.name AS department_name, " +
                    "COUNT(e.id) AS total_employee " +
                    "FROM departments d " +
                    "LEFT JOIN employees e " +
                    "ON d.id = e.department_id " +
                    "GROUP BY d.id, d.name";

            ResultSet rs3 = st.executeQuery(sql3);

            while (rs3.next()) {

                String deptName =
                        rs3.getString("department_name");

                int total =
                        rs3.getInt("total_employee");

                System.out.println(
                        deptName + " | " + total
                );
            }

            rs1.close();
            rs2.close();
            rs3.close();
            st.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}